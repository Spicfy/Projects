#Question 2
#ITI1120
#October 2023
#Bruce Wang
#############################
def two_length_run(list):
    '''(list of nums) --> bool
    returns true if there exists a sequence of consecutive repeated values in the list
    '''
    for i in range(len(list)- 1):
        if list[i] == list[i +1]:
            return True
        
    return False
nums = (input('Please input a list of numbers seperated by space: '))
numlist = (nums.strip()).split()

numlist = [float(x) for x in numlist]
print(two_length_run(numlist))  
