#ITI1120
#October 2023
#Assignment 4 part 1Question 3
#Bruce Wang
def longest_run(list):
    '''(list of nums) --> int
    returns the length of the longest sequence of consecutively repeated values
    '''
    long = 0
    for i in range(len(list) - 1):
        counter = 0
        flag = True
        while flag and i + counter < len(list):
            if list[i] == list[i + counter]:
                counter += 1
                if counter > long:
                    long = counter
            else:
                flag = False

    return long 
nums = (input('Please input a list of numbers seperated by space: '))
numlist = (nums.strip()).split()

numlist = [float(x) for x in numlist]
print(longest_run(numlist))