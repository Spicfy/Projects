#ITI1120 
#Assignment 4 part 1 Q1
#Bruce Wang
#October 2023
def number_divisible(list, n):
    '''(list[int], int)--> int
    returns the number of integers in list that are divisible by n
    '''
    Goofy = 0
    for i in list:
        if int(i)%n == 0:
            Goofy += 1
    return Goofy

nums = (input('Please input a list of numbers seperated by space: '))
intlist = (nums.strip()).split()

intlist = [int(x) for x in intlist]
divis = int(input('Please input an integer: '))
print(number_divisible(intlist, divis))



