#IT1 1120
#Assignment 3 part 1
#Bruce Wang
#October 2023
#X = 154152 d = 2
def is_up_monotone(X, d):
    '''(str, int) --> bool
        preconditions: X should be a string containing positive integers, d should also be a positive integer, d should be able to split X into even parts of itself 
        returns True or false depending whther or not X can be up monotone when it's characters are split into groups of d
    '''
    if len(str(X))%int(d) == 0:
        strX = str(X)
        t = strX[0:int(d)]
        a = int(t)

        flag = True
        for i in range ((len(strX))//int(d)):
            if i != (int(len(strX)/int(d))-1):
                print(t, end = ', ')
                b = strX[(i + 1)*int(d): (i + 2)*int(d)]
                c = int(b)
                if a < c:
                    pass
                else:
                    flag = False
                t = str(c)
                a = c
            else:
                print(t)
        return (flag)

        

a = 40
b = a - 2
print('*' * a)
print('*' + ' '* b + '*')
print('*' + ' __Welcome to up-monotone inquiry__ ' + '  *')
print('*' + ' '*b + '*')
print('*'*a)
name= input('What is your name?: ')
a = 59
b = a - 2
x = len('*' + '     __'+ name + ', welcome to up-monotone inquiry__')
z = a - x
print('*'*a)
print('*' + ' '*b + '*')
print('*' + '     __'+ name + ', welcome to up-monotone inquiry__' + ' '*(z-1) + '*')
print('*' + ' '*b + '*')
print('*'*a)
flag=True
while flag:
    question=input(name+", would you like to test if a number admits an up-monotone split of given size? ")
    question=(question.strip()).lower()
    if question=='no':
        flag=False
    elif question == 'yes':
        print('Good choice!')
        integer = input('Enter a positive integer: ')
        if integer.isdigit() == True:
            split = input('Input the split. The split has to divide the length of ' + integer + ' i.e. ' + str(len(integer)) + ': ')
            if split.isdigit() == False:
                print('The split can only contain digits. Try again.')
            elif int(len(integer)) % int(split) != 0:
                print(split + ' Does not divide into ' + str(len(integer)) + '. Try again.')
            else:
                luffy = is_up_monotone(integer,split)      
                if luffy == True:
                    print('The sequence is up-monotone')
                else:
                    print('The sequence is not up-monotone') 
        elif integer.isdigit() == False:
            print('The input can only contain digits. Try again.')  
    else:
        print('Please enter yes or no. Try again')
a = 40
b = a - 2
bl = len('*' + '         __Good bye' + name + '!__'   + '  *')
xqc = a - bl
print('*' * a)
print('*' + ' '* b + '*')
print('*' + '        __Good bye ' + name + '!__' + ' '*xqc   + '  *')
print('*' + ' '*b + '*')
print('*'*a)

