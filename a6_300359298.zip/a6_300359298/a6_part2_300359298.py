class Point:
    'class that represents a point in the plane'

    def __init__(self, xcoord=0, ycoord=0): #self for all attributes in __init__ refer to the object we are making
        ''' (Point,number, number) -> None
        initialize point coordinates to (xcoord, ycoord)'''
        self.x = xcoord
        self.y = ycoord

    def setx(self, xcoord):
        ''' (Point,number)->None
        Sets x coordinate of point to xcoord'''
        self.x = xcoord

    def sety(self, ycoord):
        ''' (Point,number)->None
        Sets y coordinate of point to ycoord'''
        self.y = ycoord

    def get(self):
        '''(Point)->tuple
        Returns a tuple with x and y coordinates of the point'''
        return (self.x, self.y)

    def move(self, dx, dy):
        '''(Point,number,number)->None
        changes the x and y coordinates by dx and dy'''
        self.x += dx
        self.y += dy

    def __eq__(self, other):
        '''(Point,Point)->bool
        Returns True if self and other have the same coordinates'''
        return self.x == other.x and self.y == other.y
    def __repr__(self):
        '''(Point)->str
        Returns canonical string representation Point(x, y)'''
        return 'Point('+str(self.x)+','+str(self.y)+')'
    def __str__(self):
        '''(Point)->str
        Returns nice string representation Point(x, y).
        In this case we chose the same representation as in __repr__'''
        return 'Point('+str(self.x)+','+str(self.y)+')'
class Rectangle:
    def __init__(self, bottomleft, topright, colour):
        '''initializes the properties of the rectangle object 
        '''
        self.bottom = bottomleft
        self.top = topright
        self.colour = colour
    def __str__(self):
        '''(rectangle) -->str
        returns a readable string reperesentation for Rectangle(Point, Point, colour)
        '''
        return 'I am a ' + self.colour + ' rectangle with bottom left corner at ' + str(self.bottom) + ' and top right corner at ' + str(self.top)
    def __repr__(self):
        '''returns the canonical string reperesentation for Rectangle(Point, Point, colour)
        '''
        return 'Rectangle(' + str(self.bottom) + ',' +str(self.top) + ',\'' + str(self.colour) + '\')'
    def __eq__(self, other):
        '''(Rectangle, Rectangle) --> bool
        Returns true if self and other share identical properties
        '''
        return (self.bottom == other.bottom) and (self.top == other.top) and (self.colour == other.colour)

    def get_bottom_left(self):
        '''(point) --> tuple
        returns the coordinates located at the bottom left of the rectangle
        '''
        return self.bottom
    def get_top_right(self):
        '''(Point) --> tuple
        returns the coordinates located at the top right of the rectangle
        '''
        return self.top
    def get_color(self):
        '''Returns colour of object Rectangle
        '''
        return self.colour
    def reset_color(self, newcolour):
        '''Changes the colour for object rectangle
        '''
        self.colour = newcolour
    def get_perimeter(self):
        '''returns the perimeter of the rectangle
        '''
        length = abs(self.top.x - self.bottom.x )
        width = abs(self.top.y - self.bottom.y)

        return 2 * (length + width)
    def get_area(self):
        ''' returns the area of the rectangle
        '''
        length = abs(self.top.x - self.bottom.x )
        width = abs(self.top.y - self.bottom.y)
        return length * width
    def recmove(self, dx, dy):
        '''moves the coordinates of the rectangle
        '''
        self.bottom.move(dx, dy)
        self.top.move(dx, dy)
    def intersects(self, other):
        '''returns True if 2 rectangles intersect with one another and False otherwise
        '''
        return not (
            self.top.x < other.bottom.x
            or self.bottom.x > other.top.x
            or self.top.y < other.bottom.y
            or self.bottom.y > other.top.y
        )
    def contains(self, x, y):
        '''Returns True if the 2 points x and y are inside the calling rectangle 
        '''
        return ( 
            self.bottom.x<= x<=self.top.x 
            and self.bottom.y <= y <= self.top.y
        )

#r3 = Rectangle(Point(), Point(2, 1), "red")
#print(r3.get_perimeter())
#r4 = Rectangle(Point(1, 1), Point(2, 2.5), "blue")
#print(r4.get_area())

class Canvas:
    def __init__(self):
        '''initializes the Object canvas and creates a empty list to store the rectangles the user will add
        '''
        self.rectangle = []
    def __repr__(self):
        '''Returns the cananical string reperesentation of the object canvas
        '''
        return 'Canvas (' + str(self.rectangle) + ') '
    def __len__(self):
        '''Returns the length of the canvas
        '''
        return len(self.rectangle)
    def add_one_rectangle(self, newrectangle):
        '''adds a new rectangle into the canvas
        '''
        self.rectangle.append(newrectangle)
    def count_same_color(self, color):
        '''(list, str) --> int
        returns the number of rectangles that are of color, user input: color
        '''
        count = 0
        for i in self.rectangle:
            if i.get_color() == color: 
                count += 1
        return count
    def total_perimeter(self):
        '''Returns the total perimenter amongst all the rectangles contained in canvas
        '''
        totalperim = 0
        for i in self.rectangle:
            totalperim += i.get_perimeter()
        return totalperim
    def min_enclosing_rectangle(self):
        '''(list) --> object(rectangle)
        returns the minimal points that would be needed to enclose all the rectangles inside of canvas
        '''
        xbottomminlist = []
        xmaxlist = []
        yminlist = []
        ymaxlist = []
        for i in self.rectangle:
            xbottomminlist.append(i.get_bottom_left.x)
        for i in self.rectangle:
            xmaxlist.append(i.get_top_right.x)
        for i in self.rectangle:
            yminlist.append(i.get_bottom_left.y)
        for i in self.rectangle:
            ymaxlist.append(i.get_top_right.x)
        minx = min(xbottomminlist)
        xmax = max(xmaxlist)
        ymin = min(yminlist)
        ymax = max(ymaxlist)
        return Rectangle(Point(minx, ymin), Point(xmax, ymax), "red")
    def common_point(self):
        '''returns True if all the rectangles share a common point together and False otherwise
        '''
        if len(self.rectangle) <2:
            return True
        else:
            for i in range(len(self.rectangle)-1):
                for j in range(i + 1, len(self.rectangle)-1):
                    if not self.rectangle[i].intersects(self.rectangle[j]):
                        return False
            return True










