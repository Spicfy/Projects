import string

def remove_punctuation(str):
    '''(str) --> str
    returns a newstring with punctuation removed
    '''
    removepun = str.maketrans("", "", string.punctuation)
    cleanstring = str.translate(removepun)

    return cleanstring
def open_file():
    '''None->file object
    See the assignment text for what this function should do'''
    # YOUR CODE GOES HERE
    while True:
        try:
            filename = input('Enter name of the file: ').strip()
            f = open(filename)
            f.close()
            return filename
        except FileNotFoundError:
            print('There is no file with that name. Try again.')

   

def read_file(fp):
    '''(file object)->dict
    returns a dictionary with each word as a key with the set of all the line numbers that the word appears in as it's corresponding value in the dictionary'''
    # YOUR CODE GOES HERE
    splits = open(fp, 'r')
    content = splits.read()
    line = content.splitlines()

    wordlist = []
    for i in line:
        words = i.lower().split()
        wordlist.append(words)
    newfulllist = []
    for i in wordlist:
        newlist = []
        for j in i:
            s = remove_punctuation(j)
            newlist.append(s)
        newfulllist.append(newlist)

    contentdict = {}
    for i in range(len(newfulllist)):
        for j in newfulllist[i]:
            if j in contentdict:
                contentdict[j].add(i + 1)
            else:
                contentdict[j] = {i + 1}
    return contentdict
def find_coexistance(D, query):
    '''(dict,str)->list
    returns a list of sorted numbers of the line numbers that  every word in query all appear in'''
    querylist = query.split()
    linelist = []
    for i in querylist:
        lines = (D[i.lower()])
        linelist.append(lines)
    intersectlist = []  
    if len(linelist) > 1: 
        mainintersectingset = linelist[0].intersection(linelist[1])
        if len(linelist) >2:
            for i in range(2, len(linelist)):
                intersection = mainintersectingset.intersection(linelist[i])
                mainintersectingset.union(intersection)
            intersectlist.extend(list(intersection))
        else:
            intersectlist.extend(list(mainintersectingset))
    else:
        intersectlist.extend(list(linelist[0]))

    intersectlist.sort()
    return intersectlist



file=open_file()
d=read_file(file)
flag = True
while flag:
    query=input("Enter one or more words separated by spaces, or 'q' to quit: ").strip().lower()
    query = remove_punctuation(query)
    if query == 'q' or query == 'quit':
        flag = False
    else:
        splitquery = query.split()
        for i in splitquery:
            if i in d:
                check = True
            else:
                print('Word ' + i + ' not in file')
                check = False
        if check == True:
            res = find_coexistance(d, query)
            for i in res:
                print(i, end = " ")
            print()
        else:
            pass
    





